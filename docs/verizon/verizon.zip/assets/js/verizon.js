// Show and Hide Element
$("#abc").click(function () {
    $("p").hide();
});



/* $(document).ready(function () {

    $('#overlay').modal('show');
    setTimeout(function () {
        $('#overlay').modal('hide');
    }, 5000);

});

 */